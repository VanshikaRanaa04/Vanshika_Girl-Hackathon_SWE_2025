// Sample data for the application
export const doctors = [
  {
    id: 1,
    name: "Dr. Priya Patel",
    specialty: "OB/GYN",
    avatar: "PP",
    hospital: "Wellness Women's Care",
  },
  {
    id: 2,
    name: "Dr. Arjun Mehta",
    specialty: "Pediatrician",
    avatar: "AM",
    hospital: "Children's Medical Center",
  },
  {
    id: 3,
    name: "Dr. Neha Verma",
    specialty: "Fertility Specialist",
    avatar: "NV",
    hospital: "Fertility Care Center",
  },
  {
    id: 4,
    name: "Dr. Raj Kumar",
    specialty: "OB/GYN",
    avatar: "RK",
    hospital: "Mother's Hope Hospital",
  },
]

export const appointments = [
  {
    id: 1,
    doctorId: 1,
    date: "2024-05-15T10:00:00",
    type: "Regular Check-up",
    location: "Wellness Women's Care, Room 305",
    status: "scheduled",
  },
  {
    id: 2,
    doctorId: 2,
    date: "2024-05-20T14:30:00",
    type: "Ultrasound Scan",
    location: "Children's Medical Center, Room 210",
    status: "scheduled",
  },
]

export const healthMetrics = {
  weight: {
    current: 65,
    unit: "kg",
    history: [
      { date: "2024-04-01", value: 63 },
      { date: "2024-04-08", value: 63.5 },
      { date: "2024-04-15", value: 64 },
      { date: "2024-04-22", value: 64.5 },
      { date: "2024-04-29", value: 65 },
    ],
  },
  bloodPressure: {
    current: { systolic: 118, diastolic: 75 },
    history: [
      { date: "2024-04-01", systolic: 120, diastolic: 80 },
      { date: "2024-04-08", systolic: 118, diastolic: 78 },
      { date: "2024-04-15", systolic: 119, diastolic: 76 },
      { date: "2024-04-22", systolic: 117, diastolic: 75 },
      { date: "2024-04-29", systolic: 118, diastolic: 75 },
    ],
  },
}

export const moodTracking = {
  current: "good",
  history: [
    { date: "2024-04-29", mood: "good", notes: "Feeling energetic" },
    { date: "2024-04-28", mood: "okay", notes: "A bit tired" },
    { date: "2024-04-27", mood: "good", notes: "Had a great day" },
    { date: "2024-04-26", mood: "low", notes: "Feeling overwhelmed" },
    { date: "2024-04-25", mood: "okay", notes: "Better than yesterday" },
  ],
}

export const feedingLogs = [
  {
    id: 1,
    timestamp: "2024-04-29T09:30:00",
    duration: 15,
    side: "left",
    notes: "Good latch, fed well",
  },
  {
    id: 2,
    timestamp: "2024-04-29T12:45:00",
    duration: 20,
    side: "right",
    notes: "Seemed hungry, fed longer",
  },
]

export const babyMetrics = {
  weight: {
    current: 3.8,
    unit: "kg",
    history: [
      { date: "2024-03-15", value: 3.2 },
      { date: "2024-03-29", value: 3.5 },
      { date: "2024-04-15", value: 3.7 },
      { date: "2024-04-29", value: 3.8 },
    ],
  },
  height: {
    current: 52,
    unit: "cm",
    history: [
      { date: "2024-03-15", value: 49 },
      { date: "2024-03-29", value: 50 },
      { date: "2024-04-15", value: 51 },
      { date: "2024-04-29", value: 52 },
    ],
  },
  headCircumference: {
    current: 35,
    unit: "cm",
    history: [
      { date: "2024-03-15", value: 33 },
      { date: "2024-03-29", value: 34 },
      { date: "2024-04-15", value: 34.5 },
      { date: "2024-04-29", value: 35 },
    ],
  },
}

export const medications = [
  {
    id: 1,
    name: "Prenatal Vitamins",
    dosage: "1 tablet",
    frequency: "daily",
    timing: "morning",
    status: "active",
  },
  {
    id: 2,
    name: "Iron Supplement",
    dosage: "1 tablet",
    frequency: "daily",
    timing: "evening",
    status: "active",
  },
]

export const vaccinations = [
  {
    id: 1,
    name: "DTaP",
    dueDate: "2024-05-15",
    status: "scheduled",
    notes: "First dose",
  },
  {
    id: 2,
    name: "Hib",
    dueDate: "2024-05-15",
    status: "scheduled",
    notes: "First dose",
  },
  {
    id: 3,
    name: "IPV",
    dueDate: "2024-05-15",
    status: "scheduled",
    notes: "First dose",
  },
]

