import Link from "next/link"
import { Calendar, FileText, Clock, ArrowRight, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function DoctorDashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-pink-800 sm:text-3xl">Welcome, Dr. Smith</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Link href="/doctor-dashboard/appointments" className="block">
          <Card className="h-full transition-all hover:border-pink-300 hover:shadow-md">
            <CardHeader className="bg-gradient-to-r from-pink-100 to-pink-200 pb-2">
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-pink-600 text-white">
                <Calendar className="h-6 w-6" />
              </div>
              <CardTitle className="text-pink-800">Appointment Management</CardTitle>
              <CardDescription>View and manage patient consultations</CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-pink-600" />
                  <span>View upcoming appointments</span>
                </li>
                <li className="flex items-center gap-2">
                  <User className="h-4 w-4 text-pink-600" />
                  <span>Manage patient schedules</span>
                </li>
                <li className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-pink-600" />
                  <span>Calendar view for scheduling</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                variant="ghost"
                className="w-full justify-between text-pink-700 hover:bg-pink-100 hover:text-pink-800"
              >
                <span>Enter Section</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </Link>

        <Link href="/doctor-dashboard/diagnostics" className="block">
          <Card className="h-full transition-all hover:border-pink-300 hover:shadow-md">
            <CardHeader className="bg-gradient-to-r from-pink-100 to-pink-200 pb-2">
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-pink-600 text-white">
                <FileText className="h-6 w-6" />
              </div>
              <CardTitle className="text-pink-800">Diagnostic Assistant</CardTitle>
              <CardDescription>Analyze and interpret medical reports</CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-pink-600" />
                  <span>MRI & CT Scan Analysis</span>
                </li>
                <li className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-pink-600" />
                  <span>Ultrasound & Biometric Reports</span>
                </li>
                <li className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-pink-600" />
                  <span>Blood Test Reports & Risk Assessment</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                variant="ghost"
                className="w-full justify-between text-pink-700 hover:bg-pink-100 hover:text-pink-800"
              >
                <span>Enter Section</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </Link>
      </div>

      <div className="mt-8">
        <h2 className="mb-4 text-xl font-semibold text-pink-800">Today's Appointments</h2>
        <Card>
          <CardContent className="p-0">
            <div className="divide-y divide-pink-100">
              <div className="flex items-center justify-between p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                    <span className="text-sm font-medium">JD</span>
                  </div>
                  <div>
                    <h3 className="font-medium text-pink-800">Jane Doe</h3>
                    <p className="text-sm text-pink-600">Fertility Consultation</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-pink-800">10:00 AM</p>
                  <p className="text-sm text-pink-600">Virtual</p>
                </div>
              </div>
              <div className="flex items-center justify-between p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                    <span className="text-sm font-medium">EJ</span>
                  </div>
                  <div>
                    <h3 className="font-medium text-pink-800">Emily Johnson</h3>
                    <p className="text-sm text-pink-600">Ultrasound Review</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-pink-800">11:30 AM</p>
                  <p className="text-sm text-pink-600">Room 305</p>
                </div>
              </div>
              <div className="flex items-center justify-between p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                    <span className="text-sm font-medium">SL</span>
                  </div>
                  <div>
                    <h3 className="font-medium text-pink-800">Sarah Lee</h3>
                    <p className="text-sm text-pink-600">Postpartum Checkup</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-pink-800">2:00 PM</p>
                  <p className="text-sm text-pink-600">Room 210</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="bg-pink-50 px-4 py-3">
            <Button variant="outline" className="w-full border-pink-300 text-pink-700 hover:bg-pink-100">
              View All Appointments
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

