import { Filter, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AppointmentsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h1 className="text-2xl font-bold text-pink-800 sm:text-3xl">Appointment Management</h1>
        <Button className="bg-pink-600 hover:bg-pink-700">
          <Plus className="mr-2 h-4 w-4" />
          New Appointment
        </Button>
      </div>

      <div className="flex flex-col gap-4 md:flex-row">
        <div className="flex-1 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle>Appointment Calendar</CardTitle>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 gap-1 border-pink-200 text-pink-700 hover:bg-pink-100"
                  >
                    <Filter className="h-3.5 w-3.5" />
                    <span>Filter</span>
                  </Button>
                  <Select defaultValue="week">
                    <SelectTrigger className="h-8 w-[110px] border-pink-200">
                      <SelectValue placeholder="View" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="day">Day</SelectItem>
                      <SelectItem value="week">Week</SelectItem>
                      <SelectItem value="month">Month</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <CardDescription>Manage your schedule and patient appointments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border border-pink-200">
                <div className="grid grid-cols-7 gap-px border-b border-pink-200 bg-pink-50 text-center">
                  <div className="bg-white py-2 text-sm font-medium text-pink-800">Sun</div>
                  <div className="bg-white py-2 text-sm font-medium text-pink-800">Mon</div>
                  <div className="bg-white py-2 text-sm font-medium text-pink-800">Tue</div>
                  <div className="bg-white py-2 text-sm font-medium text-pink-800">Wed</div>
                  <div className="bg-white py-2 text-sm font-medium text-pink-800">Thu</div>
                  <div className="bg-white py-2 text-sm font-medium text-pink-800">Fri</div>
                  <div className="bg-white py-2 text-sm font-medium text-pink-800">Sat</div>
                </div>
                <div className="grid grid-cols-7 gap-px bg-pink-50">
                  {/* Calendar cells */}
                  {Array.from({ length: 35 }).map((_, i) => (
                    <div key={i} className="min-h-[100px] bg-white p-1">
                      <div className="text-right text-sm text-gray-500">{i + 1}</div>
                      {/* Example appointment */}
                      {i === 10 && (
                        <div className="mt-1 rounded bg-pink-100 p-1 text-xs text-pink-800">
                          <div className="font-medium">Jane Doe</div>
                          <div>10:00 AM</div>
                        </div>
                      )}
                      {i === 11 && (
                        <div className="mt-1 rounded bg-pink-100 p-1 text-xs text-pink-800">
                          <div className="font-medium">Emily Johnson</div>
                          <div>11:30 AM</div>
                        </div>
                      )}
                      {i === 12 && (
                        <div className="mt-1 rounded bg-pink-100 p-1 text-xs text-pink-800">
                          <div className="font-medium">Sarah Lee</div>
                          <div>2:00 PM</div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="w-full space-y-4 md:w-80">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Today's Schedule</CardTitle>
              <CardDescription>April 15, 2023</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-pink-100">
                <div className="flex items-center justify-between p-4">
                  <div>
                    <h3 className="font-medium text-pink-800">Jane Doe</h3>
                    <p className="text-sm text-pink-600">Fertility Consultation</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-pink-800">10:00 AM</p>
                    <p className="text-sm text-pink-600">Virtual</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4">
                  <div>
                    <h3 className="font-medium text-pink-800">Emily Johnson</h3>
                    <p className="text-sm text-pink-600">Ultrasound Review</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-pink-800">11:30 AM</p>
                    <p className="text-sm text-pink-600">Room 305</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4">
                  <div>
                    <h3 className="font-medium text-pink-800">Sarah Lee</h3>
                    <p className="text-sm text-pink-600">Postpartum Checkup</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-pink-800">2:00 PM</p>
                    <p className="text-sm text-pink-600">Room 210</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Patient Search</CardTitle>
              <CardDescription>Find and manage patient appointments</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-pink-500" />
                  <Input type="search" placeholder="Search patients..." className="pl-8 border-pink-200" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="rounded-lg border border-pink-200 p-3 hover:bg-pink-50">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                      <span className="text-sm font-medium">JD</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-pink-800">Jane Doe</h4>
                      <p className="text-sm text-pink-600">Patient ID: #12345</p>
                    </div>
                  </div>
                </div>
                <div className="rounded-lg border border-pink-200 p-3 hover:bg-pink-50">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                      <span className="text-sm font-medium">EJ</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-pink-800">Emily Johnson</h4>
                      <p className="text-sm text-pink-600">Patient ID: #12346</p>
                    </div>
                  </div>
                </div>
                <div className="rounded-lg border border-pink-200 p-3 hover:bg-pink-50">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                      <span className="text-sm font-medium">SL</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-pink-800">Sarah Lee</h4>
                      <p className="text-sm text-pink-600">Patient ID: #12347</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

