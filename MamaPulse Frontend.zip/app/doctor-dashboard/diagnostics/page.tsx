import { FileText, Upload, Search, Filter, Download } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function DiagnosticsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h1 className="text-2xl font-bold text-pink-800 sm:text-3xl">Diagnostic Assistant</h1>
        <Button className="bg-pink-600 hover:bg-pink-700">
          <Upload className="mr-2 h-4 w-4" />
          Upload New Report
        </Button>
      </div>

      <Tabs defaultValue="mri" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-pink-100">
          <TabsTrigger value="mri" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
            MRI Scans
          </TabsTrigger>
          <TabsTrigger value="ct" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
            CT Scans
          </TabsTrigger>
          <TabsTrigger value="ultrasound" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
            Ultrasound
          </TabsTrigger>
          <TabsTrigger value="blood" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
            Blood Tests
          </TabsTrigger>
        </TabsList>

        <div className="mt-6 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-pink-500" />
            <Input type="search" placeholder="Search reports..." className="pl-8 border-pink-200" />
          </div>
          <Select defaultValue="recent">
            <SelectTrigger className="w-[160px] border-pink-200">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recent">Most Recent</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="patient">Patient Name</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2 border-pink-200 text-pink-700 hover:bg-pink-100">
            <Filter className="h-4 w-4" />
            Filter
          </Button>
        </div>

        <TabsContent value="mri" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Brain MRI</CardTitle>
                  <div className="flex h-6 items-center rounded-full bg-pink-100 px-2 text-xs font-medium text-pink-800">
                    New
                  </div>
                </div>
                <CardDescription>Patient: Jane Doe</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video overflow-hidden rounded-md bg-pink-100">
                  <div className="flex h-full items-center justify-center">
                    <FileText className="h-12 w-12 text-pink-300" />
                  </div>
                </div>
                <div className="mt-3">
                  <p className="text-sm text-pink-600">Uploaded: April 14, 2023</p>
                  <p className="text-sm text-pink-600">Referring Doctor: Dr. Johnson</p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                  View Details
                </Button>
                <Button className="bg-pink-600 hover:bg-pink-700">Analyze</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Pelvic MRI</CardTitle>
                <CardDescription>Patient: Emily Johnson</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video overflow-hidden rounded-md bg-pink-100">
                  <div className="flex h-full items-center justify-center">
                    <FileText className="h-12 w-12 text-pink-300" />
                  </div>
                </div>
                <div className="mt-3">
                  <p className="text-sm text-pink-600">Uploaded: April 10, 2023</p>
                  <p className="text-sm text-pink-600">Referring Doctor: Dr. Patel</p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                  View Details
                </Button>
                <Button className="bg-pink-600 hover:bg-pink-700">Analyze</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Abdominal MRI</CardTitle>
                <CardDescription>Patient: Sarah Lee</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video overflow-hidden rounded-md bg-pink-100">
                  <div className="flex h-full items-center justify-center">
                    <FileText className="h-12 w-12 text-pink-300" />
                  </div>
                </div>
                <div className="mt-3">
                  <p className="text-sm text-pink-600">Uploaded: April 5, 2023</p>
                  <p className="text-sm text-pink-600">Referring Doctor: Dr. Chen</p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                  View Details
                </Button>
                <Button className="bg-pink-600 hover:bg-pink-700">Analyze</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="ultrasound" className="mt-4">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Ultrasound Analysis</CardTitle>
              <CardDescription>Detailed report for Emily Johnson's 20-week ultrasound</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <div className="aspect-video overflow-hidden rounded-md bg-pink-100">
                    <div className="flex h-full items-center justify-center">
                      <FileText className="h-12 w-12 text-pink-300" />
                    </div>
                  </div>
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium text-pink-700">Patient:</span>
                      <span className="text-sm text-pink-800">Emily Johnson</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium text-pink-700">Date:</span>
                      <span className="text-sm text-pink-800">April 12, 2023</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium text-pink-700">Gestational Age:</span>
                      <span className="text-sm text-pink-800">20 weeks 3 days</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium text-pink-700">Referring Doctor:</span>
                      <span className="text-sm text-pink-800">Dr. Amelia Patel</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="rounded-lg bg-pink-50 p-4">
                    <h3 className="mb-2 font-medium text-pink-800">AI Analysis Summary</h3>
                    <p className="text-sm text-pink-700">
                      The ultrasound shows normal fetal development consistent with gestational age. Fetal biometry
                      measurements are within normal range. No structural abnormalities detected.
                    </p>
                  </div>
                  <div>
                    <h3 className="mb-2 font-medium text-pink-800">Biometric Measurements</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-pink-700">Biparietal Diameter (BPD):</span>
                        <span className="text-sm font-medium text-pink-800">48.2 mm (50th percentile)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-pink-700">Head Circumference (HC):</span>
                        <span className="text-sm font-medium text-pink-800">174.3 mm (55th percentile)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-pink-700">Abdominal Circumference (AC):</span>
                        <span className="text-sm font-medium text-pink-800">153.1 mm (48th percentile)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-pink-700">Femur Length (FL):</span>
                        <span className="text-sm font-medium text-pink-800">33.5 mm (52nd percentile)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-pink-700">Estimated Fetal Weight (EFW):</span>
                        <span className="text-sm font-medium text-pink-800">345g (51st percentile)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                <Download className="mr-2 h-4 w-4" />
                Download Report
              </Button>
              <Button className="bg-pink-600 hover:bg-pink-700">Share with Patient</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

