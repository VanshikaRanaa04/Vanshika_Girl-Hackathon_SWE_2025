import type React from "react"
import Link from "next/link"
import { Calendar, User, Bell, Settings, LogOut, FileText } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DoctorDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen flex-col bg-pink-50">
      <header className="border-b border-pink-200 bg-white px-4 py-3 shadow-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <Link href="/doctor-dashboard">
            <h1 className="text-xl font-bold text-pink-700">MamaPulse</h1>
          </Link>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-pink-700 hover:bg-pink-100 hover:text-pink-800">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-pink-700 hover:bg-pink-100 hover:text-pink-800">
              <Settings className="h-5 w-5" />
            </Button>
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-pink-700 hover:bg-pink-100 hover:text-pink-800">
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
            <Button
              variant="outline"
              className="ml-2 gap-2 border-pink-200 text-pink-700 hover:bg-pink-100 hover:text-pink-800"
            >
              <User className="h-4 w-4" />
              <span>Dr. Smith</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto w-full max-w-7xl px-4 py-6">
        <Tabs defaultValue="appointments" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-pink-100">
            <TabsTrigger
              value="appointments"
              className="flex items-center gap-2 data-[state=active]:bg-pink-600 data-[state=active]:text-white"
              asChild
            >
              <Link href="/doctor-dashboard/appointments">
                <Calendar className="h-4 w-4" />
                <span>Appointment Management</span>
              </Link>
            </TabsTrigger>
            <TabsTrigger
              value="diagnostics"
              className="flex items-center gap-2 data-[state=active]:bg-pink-600 data-[state=active]:text-white"
              asChild
            >
              <Link href="/doctor-dashboard/diagnostics">
                <FileText className="h-4 w-4" />
                <span>Diagnostic Assistant</span>
              </Link>
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <main className="mt-6">{children}</main>
      </div>
    </div>
  )
}

