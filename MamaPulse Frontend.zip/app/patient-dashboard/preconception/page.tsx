import { Calendar, Pill, Utensils, Clock, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PreconceptionPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h1 className="text-2xl font-bold text-pink-800 sm:text-3xl">Preconception Planning</h1>
        <Button className="bg-pink-600 hover:bg-pink-700">
          <Plus className="mr-2 h-4 w-4" />
          Schedule Appointment
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-pink-600">Cycle Day</CardTitle>
            <CardDescription>Current cycle: 28 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <span className="text-3xl font-bold text-pink-800">14</span>
              <p className="text-sm text-pink-600">Ovulation Day</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-pink-600">Fertility Window</CardTitle>
            <CardDescription>Next 3 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center gap-1">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-pink-100 text-pink-800">12</div>
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-pink-200 text-pink-800">13</div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-600 text-white font-bold">
                14
              </div>
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-pink-200 text-pink-800">15</div>
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-pink-100 text-pink-800">16</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-pink-600">Basal Temperature</CardTitle>
            <CardDescription>Last 7 days average</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <span className="text-3xl font-bold text-pink-800">97.8°F</span>
              <p className="text-sm text-pink-600">
                <span className="text-green-600">↑ 0.4°F</span> from last week
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-pink-600">Fertility Score</CardTitle>
            <CardDescription>Based on your data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-pink-600">Score</span>
                <span className="text-sm font-medium text-pink-800">85/100</span>
              </div>
              <Progress value={85} className="h-2 bg-pink-100" indicatorClassName="bg-pink-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="cycle" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-pink-100">
          <TabsTrigger value="cycle" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
            <Calendar className="mr-2 h-4 w-4" />
            Cycle Tracking
          </TabsTrigger>
          <TabsTrigger value="treatment" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
            <Pill className="mr-2 h-4 w-4" />
            Treatment
          </TabsTrigger>
          <TabsTrigger value="diet" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
            <Utensils className="mr-2 h-4 w-4" />
            Diet & Lifestyle
          </TabsTrigger>
          <TabsTrigger value="appointments" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
            <Clock className="mr-2 h-4 w-4" />
            Appointments
          </TabsTrigger>
        </TabsList>

        <TabsContent value="cycle" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Cycle & Fertility Tracking</CardTitle>
              <CardDescription>Monitor your menstrual cycle and ovulation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-lg bg-pink-50 p-4">
                  <h3 className="mb-2 font-medium text-pink-800">Cycle Overview</h3>
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div>
                      <p className="text-sm text-pink-600">Average Cycle Length</p>
                      <p className="text-lg font-medium text-pink-800">28 days</p>
                    </div>
                    <div>
                      <p className="text-sm text-pink-600">Last Period Started</p>
                      <p className="text-lg font-medium text-pink-800">April 1, 2023</p>
                    </div>
                    <div>
                      <p className="text-sm text-pink-600">Next Period Expected</p>
                      <p className="text-lg font-medium text-pink-800">April 29, 2023</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="mb-2 font-medium text-pink-800">Fertility Calendar</h3>
                  <div className="rounded-lg border border-pink-200 p-4">
                    <div className="grid grid-cols-7 gap-1 text-center">
                      <div className="text-xs font-medium text-pink-600">Sun</div>
                      <div className="text-xs font-medium text-pink-600">Mon</div>
                      <div className="text-xs font-medium text-pink-600">Tue</div>
                      <div className="text-xs font-medium text-pink-600">Wed</div>
                      <div className="text-xs font-medium text-pink-600">Thu</div>
                      <div className="text-xs font-medium text-pink-600">Fri</div>
                      <div className="text-xs font-medium text-pink-600">Sat</div>

                      {/* Calendar days - first row */}
                      <div className="h-10 rounded-md p-1 text-center text-sm text-gray-400">26</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm text-gray-400">27</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm text-gray-400">28</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm text-gray-400">29</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm text-gray-400">30</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm text-gray-400">31</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">1</div>

                      {/* Calendar days - second row */}
                      <div className="h-10 rounded-md p-1 text-center text-sm">2</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">3</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">4</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">5</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">6</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">7</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">8</div>

                      {/* Calendar days - third row */}
                      <div className="h-10 rounded-md p-1 text-center text-sm">9</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">10</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">11</div>
                      <div className="h-10 rounded-md bg-pink-100 p-1 text-center text-sm">12</div>
                      <div className="h-10 rounded-md bg-pink-200 p-1 text-center text-sm">13</div>
                      <div className="h-10 rounded-md bg-pink-600 p-1 text-center text-sm font-bold text-white">14</div>
                      <div className="h-10 rounded-md bg-pink-200 p-1 text-center text-sm">15</div>

                      {/* Calendar days - fourth row */}
                      <div className="h-10 rounded-md bg-pink-100 p-1 text-center text-sm">16</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">17</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">18</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">19</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">20</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">21</div>
                      <div className="h-10 rounded-md p-1 text-center text-sm">22</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-pink-600 hover:bg-pink-700">Log Today's Data</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="treatment" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>IVF & Treatment Schedule</CardTitle>
              <CardDescription>Manage your fertility treatments and medications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-lg bg-pink-50 p-4">
                  <h3 className="mb-2 font-medium text-pink-800">Current Treatment Plan</h3>
                  <p className="text-sm text-pink-600">IVF Cycle 1 - Stimulation Phase</p>
                </div>

                <div>
                  <h3 className="mb-2 font-medium text-pink-800">Medication Schedule</h3>
                  <div className="space-y-2">
                    <div className="rounded-lg border border-pink-200 p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-pink-800">Gonal-F</h4>
                          <p className="text-sm text-pink-600">225 IU subcutaneous injection</p>
                        </div>
                        <p className="text-sm font-medium text-pink-800">8:00 AM Daily</p>
                      </div>
                    </div>
                    <div className="rounded-lg border border-pink-200 p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-pink-800">Menopur</h4>
                          <p className="text-sm text-pink-600">150 IU subcutaneous injection</p>
                        </div>
                        <p className="text-sm font-medium text-pink-800">8:00 PM Daily</p>
                      </div>
                    </div>
                    <div className="rounded-lg border border-pink-200 p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-pink-800">Prenatal Vitamin</h4>
                          <p className="text-sm text-pink-600">1 tablet</p>
                        </div>
                        <p className="text-sm font-medium text-pink-800">9:00 AM Daily</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="mb-2 font-medium text-pink-800">Upcoming Procedures</h3>
                  <div className="rounded-lg border border-pink-200 p-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-pink-800">Follicle Monitoring Ultrasound</h4>
                        <p className="text-sm text-pink-600">Dr. Sarah Johnson</p>
                      </div>
                      <p className="text-sm font-medium text-pink-800">April 18, 9:30 AM</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-pink-600 hover:bg-pink-700">View Complete Treatment Plan</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="diet" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Diet & Lifestyle Guidance</CardTitle>
              <CardDescription>Recommendations for reproductive health</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-lg bg-pink-50 p-4">
                  <h3 className="mb-2 font-medium text-pink-800">Nutrition Recommendations</h3>
                  <ul className="space-y-2 text-sm text-pink-700">
                    <li className="flex items-start gap-2">
                      <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-pink-200 text-xs text-pink-800">
                        ✓
                      </span>
                      <span>Increase intake of folate-rich foods (leafy greens, legumes, citrus fruits)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-pink-200 text-xs text-pink-800">
                        ✓
                      </span>
                      <span>Consume omega-3 fatty acids from fish or supplements</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-pink-200 text-xs text-pink-800">
                        ✓
                      </span>
                      <span>Maintain adequate iron levels with lean meats and plant sources</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-pink-200 text-xs text-pink-800">
                        ✓
                      </span>
                      <span>Stay hydrated with at least 8 glasses of water daily</span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="mb-2 font-medium text-pink-800">Lifestyle Adjustments</h3>
                  <div className="space-y-2">
                    <div className="rounded-lg border border-pink-200 p-3">
                      <h4 className="font-medium text-pink-800">Exercise Recommendations</h4>
                      <p className="text-sm text-pink-600">Moderate exercise 3-4 times per week for 30 minutes</p>
                      <div className="mt-2 flex items-center gap-2">
                        <Button variant="outline" size="sm" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                          Walking
                        </Button>
                        <Button variant="outline" size="sm" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                          Swimming
                        </Button>
                        <Button variant="outline" size="sm" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                          Yoga
                        </Button>
                      </div>
                    </div>
                    <div className="rounded-lg border border-pink-200 p-3">
                      <h4 className="font-medium text-pink-800">Stress Management</h4>
                      <p className="text-sm text-pink-600">Practice daily relaxation techniques</p>
                      <div className="mt-2 flex items-center gap-2">
                        <Button variant="outline" size="sm" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                          Meditation
                        </Button>
                        <Button variant="outline" size="sm" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                          Deep Breathing
                        </Button>
                        <Button variant="outline" size="sm" className="border-pink-200 text-pink-700 hover:bg-pink-100">
                          Journaling
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-pink-600 hover:bg-pink-700">Get Personalized Plan</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="appointments" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Schedule Appointment</CardTitle>
              <CardDescription>Book consultations with fertility specialists</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-lg bg-pink-50 p-4">
                  <h3 className="mb-2 font-medium text-pink-800">Upcoming Appointments</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-pink-800">Fertility Consultation</p>
                        <p className="text-sm text-pink-600">Dr. Sarah Johnson</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-pink-800">Tomorrow, 10:00 AM</p>
                        <p className="text-sm text-pink-600">Virtual Appointment</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="mb-2 font-medium text-pink-800">Available Specialists</h3>
                  <div className="space-y-2">
                    <div className="rounded-lg border border-pink-200 p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                            <span className="text-sm font-medium">SJ</span>
                          </div>
                          <div>
                            <h4 className="font-medium text-pink-800">Dr. Sarah Johnson</h4>
                            <p className="text-sm text-pink-600">Reproductive Endocrinologist</p>
                          </div>
                        </div>
                        <Button size="sm" className="bg-pink-600 hover:bg-pink-700">
                          Book
                        </Button>
                      </div>
                    </div>
                    <div className="rounded-lg border border-pink-200 p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                            <span className="text-sm font-medium">MC</span>
                          </div>
                          <div>
                            <h4 className="font-medium text-pink-800">Dr. Michael Chen</h4>
                            <p className="text-sm text-pink-600">Fertility Specialist</p>
                          </div>
                        </div>
                        <Button size="sm" className="bg-pink-600 hover:bg-pink-700">
                          Book
                        </Button>
                      </div>
                    </div>
                    <div className="rounded-lg border border-pink-200 p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-pink-800">
                            <span className="text-sm font-medium">AP</span>
                          </div>
                          <div>
                            <h4 className="font-medium text-pink-800">Dr. Amelia Patel</h4>
                            <p className="text-sm text-pink-600">OB/GYN, Fertility Counselor</p>
                          </div>
                        </div>
                        <Button size="sm" className="bg-pink-600 hover:bg-pink-700">
                          Book
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-pink-600 hover:bg-pink-700">View All Specialists</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

