import { Calendar, Baby, Utensils, Activity, LineChart, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function PregnancyPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-pink-800 sm:text-3xl">Pregnancy & Maternal Care</h1>
          <p className="mt-1 text-pink-600">Welcome, Gauri</p>
        </div>
        <Button className="bg-pink-600 hover:bg-pink-700">
          <Plus className="mr-2 h-4 w-4" />
          Schedule Check-up
        </Button>
      </div>

      {/* Progress Overview */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Pregnancy Progress</CardTitle>
          <CardDescription>Second Trimester</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="mb-2 flex justify-between text-sm">
                <span className="text-pink-700">Progress</span>
                <span className="font-medium text-pink-800">60%</span>
              </div>
              <Progress value={60} className="h-2 bg-pink-100" indicatorClassName="bg-pink-600" />
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="rounded-lg bg-pink-50 p-3">
                <div className="text-sm text-pink-600">Current Week</div>
                <div className="mt-1 text-2xl font-bold text-pink-800">24</div>
                <div className="text-sm text-pink-600">Second Trimester</div>
              </div>
              <div className="rounded-lg bg-pink-50 p-3">
                <div className="text-sm text-pink-600">Due Date</div>
                <div className="mt-1 text-2xl font-bold text-pink-800">Aug 15</div>
                <div className="text-sm text-pink-600">16 weeks remaining</div>
              </div>
              <div className="rounded-lg bg-pink-50 p-3">
                <div className="text-sm text-pink-600">Baby Size</div>
                <div className="mt-1 text-2xl font-bold text-pink-800">12.5 in</div>
                <div className="text-sm text-pink-600">Size of a cantaloupe</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Weekly Updates */}
        <Card>
          <CardHeader>
            <CardTitle>Week 24 Updates</CardTitle>
            <CardDescription>Your baby's development this week</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="rounded-lg bg-pink-50 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Baby's Development</h3>
                <ul className="space-y-2 text-sm text-pink-700">
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-pink-200 text-xs text-pink-800">
                      ✓
                    </span>
                    <span>Baby's face is almost fully formed</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-pink-200 text-xs text-pink-800">
                      ✓
                    </span>
                    <span>Hearing is fully developed</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-pink-200 text-xs text-pink-800">
                      ✓
                    </span>
                    <span>Regular movement patterns established</span>
                  </li>
                </ul>
              </div>

              <div className="rounded-lg border border-pink-200 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Your Body Changes</h3>
                <ul className="space-y-2 text-sm text-pink-700">
                  <li>• Increased appetite</li>
                  <li>• Stretch marks may appear</li>
                  <li>• Backache and round ligament pain</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Health Metrics */}
        <Card>
          <CardHeader>
            <CardTitle>Health Tracking</CardTitle>
            <CardDescription>Your weekly health metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-lg border border-pink-200 p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-pink-600">Weight</div>
                      <div className="text-xl font-bold text-pink-800">145 lbs</div>
                    </div>
                    <LineChart className="h-5 w-5 text-pink-600" />
                  </div>
                  <div className="mt-1 text-xs text-green-600">+1.2 lbs this week</div>
                </div>
                <div className="rounded-lg border border-pink-200 p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-pink-600">Blood Pressure</div>
                      <div className="text-xl font-bold text-pink-800">118/75</div>
                    </div>
                    <Activity className="h-5 w-5 text-pink-600" />
                  </div>
                  <div className="mt-1 text-xs text-pink-600">Normal range</div>
                </div>
              </div>

              <div className="rounded-lg bg-pink-50 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Today's To-Do</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center justify-between">
                    <span className="text-pink-700">Take prenatal vitamins</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-pink-700 hover:bg-pink-100 hover:text-pink-800"
                    >
                      Mark Done
                    </Button>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-pink-700">Log blood pressure</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-pink-700 hover:bg-pink-100 hover:text-pink-800"
                    >
                      Log Now
                    </Button>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-pink-700">30min walking exercise</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-pink-700 hover:bg-pink-100 hover:text-pink-800"
                    >
                      Start
                    </Button>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Nutrition & Exercise */}
      <Card>
        <CardHeader>
          <CardTitle>Prenatal Wellness</CardTitle>
          <CardDescription>Your personalized nutrition and exercise plan</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <h3 className="mb-3 font-medium text-pink-800">Today's Meal Plan</h3>
              <div className="space-y-3">
                <div className="rounded-lg border border-pink-200 p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-pink-800">Breakfast</div>
                      <div className="text-sm text-pink-600">8:00 AM</div>
                    </div>
                    <Utensils className="h-5 w-5 text-pink-600" />
                  </div>
                  <div className="mt-2 text-sm text-pink-700">
                    Oatmeal with berries, Greek yogurt, and a handful of nuts
                  </div>
                </div>
                <div className="rounded-lg border border-pink-200 p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-pink-800">Lunch</div>
                      <div className="text-sm text-pink-600">12:30 PM</div>
                    </div>
                    <Utensils className="h-5 w-5 text-pink-600" />
                  </div>
                  <div className="mt-2 text-sm text-pink-700">Grilled chicken salad with avocado and quinoa</div>
                </div>
                <div className="rounded-lg border border-pink-200 p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-pink-800">Dinner</div>
                      <div className="text-sm text-pink-600">6:30 PM</div>
                    </div>
                    <Utensils className="h-5 w-5 text-pink-600" />
                  </div>
                  <div className="mt-2 text-sm text-pink-700">
                    Baked salmon with sweet potato and steamed vegetables
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="mb-3 font-medium text-pink-800">Exercise Recommendations</h3>
              <div className="space-y-3">
                <div className="rounded-lg bg-pink-50 p-4">
                  <h4 className="font-medium text-pink-800">Safe Activities for Week 24</h4>
                  <ul className="mt-2 space-y-2 text-sm text-pink-700">
                    <li>• Prenatal yoga (20 minutes)</li>
                    <li>• Walking (30 minutes)</li>
                    <li>• Swimming (20 minutes)</li>
                    <li>• Light stretching (10 minutes)</li>
                  </ul>
                </div>
                <Button className="w-full bg-pink-600 hover:bg-pink-700">View Exercise Videos</Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Appointments */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Appointments</CardTitle>
          <CardDescription>Your scheduled check-ups and consultations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="divide-y divide-pink-100">
            <div className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <Calendar className="h-5 w-5 text-pink-600" />
                <div>
                  <div className="font-medium text-pink-800">Regular Check-up</div>
                  <div className="text-sm text-pink-600">Dr. Sarah Johnson</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium text-pink-800">Tomorrow, 10:00 AM</div>
                <div className="text-sm text-pink-600">Memorial Hospital</div>
              </div>
            </div>
            <div className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <Baby className="h-5 w-5 text-pink-600" />
                <div>
                  <div className="font-medium text-pink-800">Ultrasound Scan</div>
                  <div className="text-sm text-pink-600">Dr. Michael Chen</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium text-pink-800">May 20, 2:30 PM</div>
                <div className="text-sm text-pink-600">Women's Care Center</div>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full border-pink-200 text-pink-700 hover:bg-pink-100">
            View All Appointments
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

