import { Baby, Heart, Plus, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function PostpartumPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-pink-800 sm:text-3xl">Postpartum & Childcare</h1>
          <p className="mt-1 text-pink-600">Welcome, Gauri</p>
        </div>
        <Button className="bg-pink-600 hover:bg-pink-700">
          <Plus className="mr-2 h-4 w-4" />
          Schedule Check-up
        </Button>
      </div>

      {/* Mental Health Monitoring */}
      <Card>
        <CardHeader>
          <CardTitle>Mental Health Check-in</CardTitle>
          <CardDescription>Track your emotional well-being</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div className="rounded-lg bg-pink-50 p-4">
                <h3 className="mb-3 font-medium text-pink-800">Today's Mood</h3>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 border-pink-200 bg-white text-pink-700 hover:bg-pink-100">
                    😊 Good
                  </Button>
                  <Button variant="outline" className="flex-1 border-pink-200 bg-white text-pink-700 hover:bg-pink-100">
                    😐 Okay
                  </Button>
                  <Button variant="outline" className="flex-1 border-pink-200 bg-white text-pink-700 hover:bg-pink-100">
                    😔 Low
                  </Button>
                </div>
              </div>
              <div className="rounded-lg border border-pink-200 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Symptoms Check</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-pink-700">Feeling overwhelmed</span>
                    <div className="space-x-1">
                      <Button variant="ghost" size="sm" className="h-7 px-3 text-pink-700 hover:bg-pink-100">
                        No
                      </Button>
                      <Button variant="ghost" size="sm" className="h-7 px-3 text-pink-700 hover:bg-pink-100">
                        Yes
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-pink-700">Difficulty sleeping</span>
                    <div className="space-x-1">
                      <Button variant="ghost" size="sm" className="h-7 px-3 text-pink-700 hover:bg-pink-100">
                        No
                      </Button>
                      <Button variant="ghost" size="sm" className="h-7 px-3 text-pink-700 hover:bg-pink-100">
                        Yes
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-pink-700">Loss of appetite</span>
                    <div className="space-x-1">
                      <Button variant="ghost" size="sm" className="h-7 px-3 text-pink-700 hover:bg-pink-100">
                        No
                      </Button>
                      <Button variant="ghost" size="sm" className="h-7 px-3 text-pink-700 hover:bg-pink-100">
                        Yes
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="rounded-lg bg-pink-50 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Support Resources</h3>
                <ul className="space-y-2 text-sm text-pink-700">
                  <li>• 24/7 Postpartum Support Hotline</li>
                  <li>• Online Support Groups</li>
                  <li>• Local Counseling Services</li>
                </ul>
                <Button className="mt-3 w-full bg-pink-600 hover:bg-pink-700">Connect with Counselor</Button>
              </div>
              <div className="rounded-lg border border-pink-200 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Weekly Mood Trend</h3>
                <div className="h-32 w-full rounded-md bg-pink-100"></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Baby Growth Tracker */}
      <Card>
        <CardHeader>
          <CardTitle>Baby Growth Tracker</CardTitle>
          <CardDescription>Monitor your baby's development</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-3">
            <div className="space-y-4">
              <div className="rounded-lg bg-pink-50 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Current Stats</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-pink-700">Weight</span>
                    <span className="text-sm font-medium text-pink-800">8.5 lbs</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-pink-700">Height</span>
                    <span className="text-sm font-medium text-pink-800">21 inches</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-pink-700">Head Circumference</span>
                    <span className="text-sm font-medium text-pink-800">14 inches</span>
                  </div>
                </div>
                <Button className="mt-3 w-full bg-pink-600 hover:bg-pink-700">Update Measurements</Button>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-pink-200 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Upcoming Vaccinations</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center justify-between">
                    <span className="text-pink-700">DTaP (2 months)</span>
                    <Button variant="outline" size="sm" className="h-7 border-pink-200 text-pink-700 hover:bg-pink-100">
                      Schedule
                    </Button>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-pink-700">Hib (2 months)</span>
                    <Button variant="outline" size="sm" className="h-7 border-pink-200 text-pink-700 hover:bg-pink-100">
                      Schedule
                    </Button>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-pink-700">IPV (2 months)</span>
                    <Button variant="outline" size="sm" className="h-7 border-pink-200 text-pink-700 hover:bg-pink-100">
                      Schedule
                    </Button>
                  </li>
                </ul>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-pink-200 p-4">
                <h3 className="mb-2 font-medium text-pink-800">Development Milestones</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100 text-xs text-green-700">
                      ✓
                    </span>
                    <span className="text-pink-700">Lifts head during tummy time</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100 text-xs text-green-700">
                      ✓
                    </span>
                    <span className="text-pink-700">Follows objects with eyes</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-pink-100 text-xs text-pink-700">
                      ○
                    </span>
                    <span className="text-pink-700">First social smile</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Breastfeeding & Nutrition */}
      <Card>
        <CardHeader>
          <CardTitle>Breastfeeding & Nutrition</CardTitle>
          <CardDescription>Track feeding patterns and get nutrition guidance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <h3 className="mb-3 font-medium text-pink-800">Today's Feeding Log</h3>
              <div className="space-y-3">
                <div className="rounded-lg border border-pink-200 p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-pink-800">Last Feed</div>
                      <div className="text-sm text-pink-600">Left side, 15 minutes</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-pink-800">9:30 AM</div>
                      <div className="text-sm text-pink-600">2 hours ago</div>
                    </div>
                  </div>
                </div>
                <Button className="w-full bg-pink-600 hover:bg-pink-700">Log New Feed</Button>
              </div>

              <div className="mt-4">
                <h3 className="mb-3 font-medium text-pink-800">Your Nutrition Plan</h3>
                <div className="rounded-lg bg-pink-50 p-4">
                  <h4 className="mb-2 font-medium text-pink-800">Recommended Daily Intake</h4>
                  <ul className="space-y-2 text-sm text-pink-700">
                    <li>• Extra 500 calories for breastfeeding</li>
                    <li>• 8-10 glasses of water</li>
                    <li>• Calcium-rich foods</li>
                    <li>• Iron-rich foods</li>
                  </ul>
                </div>
              </div>
            </div>

            <div>
              <h3 className="mb-3 font-medium text-pink-800">Support & Resources</h3>
              <div className="space-y-3">
                <div className="rounded-lg border border-pink-200 p-4">
                  <h4 className="font-medium text-pink-800">Common Concerns</h4>
                  <ul className="mt-2 space-y-2 text-sm text-pink-700">
                    <li>• Proper latch techniques</li>
                    <li>• Milk supply management</li>
                    <li>• Feeding positions</li>
                    <li>• Pumping and storage</li>
                  </ul>
                  <Button className="mt-3 w-full bg-pink-600 hover:bg-pink-700">Contact Lactation Consultant</Button>
                </div>

                <div className="rounded-lg bg-pink-50 p-4">
                  <h4 className="font-medium text-pink-800">Helpful Resources</h4>
                  <div className="mt-2 space-y-2">
                    <Button
                      variant="outline"
                      className="w-full justify-between border-pink-200 text-pink-700 hover:bg-pink-100"
                    >
                      <span>Breastfeeding Guide</span>
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-between border-pink-200 text-pink-700 hover:bg-pink-100"
                    >
                      <span>Video Tutorials</span>
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-between border-pink-200 text-pink-700 hover:bg-pink-100"
                    >
                      <span>Support Group</span>
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Check-ups */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Check-ups</CardTitle>
          <CardDescription>Scheduled appointments for you and your baby</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="divide-y divide-pink-100">
            <div className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <Baby className="h-5 w-5 text-pink-600" />
                <div>
                  <div className="font-medium text-pink-800">2-Month Wellness Check</div>
                  <div className="text-sm text-pink-600">Dr. Emily Peters - Pediatrician</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium text-pink-800">May 15, 10:00 AM</div>
                <div className="text-sm text-pink-600">Children's Medical Center</div>
              </div>
            </div>
            <div className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <Heart className="h-5 w-5 text-pink-600" />
                <div>
                  <div className="font-medium text-pink-800">Postpartum Check-up</div>
                  <div className="text-sm text-pink-600">Dr. Sarah Johnson</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium text-pink-800">May 20, 2:30 PM</div>
                <div className="text-sm text-pink-600">Women's Care Center</div>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full border-pink-200 text-pink-700 hover:bg-pink-100">
            Schedule New Appointment
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

