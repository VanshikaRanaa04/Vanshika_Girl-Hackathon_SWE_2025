"use client"

import { useState } from "react"
import Link from "next/link"
import { Calendar, LineChart, Pill, Utensils, ArrowRight, Egg, Heart, Baby } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AppointmentForm } from "@/components/appointment-form"
import { appointments, doctors } from "@/lib/data"

export default function PatientDashboard() {
  const [showAppointmentForm, setShowAppointmentForm] = useState(false)

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-pink-800 sm:text-3xl">Welcome, Gauri Sharma</h1>

      <div className="grid gap-6 md:grid-cols-3">
        <Link href="/patient-dashboard/preconception" className="block">
          <Card className="h-full transition-all hover:border-pink-300 hover:shadow-md">
            <CardHeader className="bg-gradient-to-r from-pink-100 to-pink-200 pb-2">
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-pink-600 text-white">
                <Egg className="h-6 w-6" />
              </div>
              <CardTitle className="text-pink-800">Preconception Planning</CardTitle>
              <CardDescription>Prepare for your fertility journey</CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-pink-600" />
                  <span>Cycle & Fertility Tracking</span>
                </li>
                <li className="flex items-center gap-2">
                  <Pill className="h-4 w-4 text-pink-600" />
                  <span>IVF & Treatment Schedule</span>
                </li>
                <li className="flex items-center gap-2">
                  <Utensils className="h-4 w-4 text-pink-600" />
                  <span>Diet & Lifestyle Guidance</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                variant="ghost"
                className="w-full justify-between text-pink-700 hover:bg-pink-100 hover:text-pink-800"
              >
                <span>Enter Section</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </Link>

        <Link href="/patient-dashboard/pregnancy" className="block">
          <Card className="h-full transition-all hover:border-pink-300 hover:shadow-md">
            <CardHeader className="bg-gradient-to-r from-pink-100 to-pink-200 pb-2">
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-pink-600 text-white">
                <Heart className="h-6 w-6" />
              </div>
              <CardTitle className="text-pink-800">Pregnancy & Maternal Care</CardTitle>
              <CardDescription>Monitor your pregnancy journey</CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <LineChart className="h-4 w-4 text-pink-600" />
                  <span>Health Monitoring</span>
                </li>
                <li className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-pink-600" />
                  <span>Appointments & Check-ups</span>
                </li>
                <li className="flex items-center gap-2">
                  <Utensils className="h-4 w-4 text-pink-600" />
                  <span>Trimester-based Meal Plans</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                variant="ghost"
                className="w-full justify-between text-pink-700 hover:bg-pink-100 hover:text-pink-800"
              >
                <span>Enter Section</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </Link>

        <Link href="/patient-dashboard/postpartum" className="block">
          <Card className="h-full transition-all hover:border-pink-300 hover:shadow-md">
            <CardHeader className="bg-gradient-to-r from-pink-100 to-pink-200 pb-2">
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-pink-600 text-white">
                <Baby className="h-6 w-6" />
              </div>
              <CardTitle className="text-pink-800">Postpartum & Childcare</CardTitle>
              <CardDescription>Support for you and your baby</CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <LineChart className="h-4 w-4 text-pink-600" />
                  <span>Recovery Monitoring</span>
                </li>
                <li className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-pink-600" />
                  <span>Child Growth & Vaccination</span>
                </li>
                <li className="flex items-center gap-2">
                  <Utensils className="h-4 w-4 text-pink-600" />
                  <span>Postpartum Nutrition</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                variant="ghost"
                className="w-full justify-between text-pink-700 hover:bg-pink-100 hover:text-pink-800"
              >
                <span>Enter Section</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </Link>
      </div>

      <div className="mt-8">
        <h2 className="mb-4 text-xl font-semibold text-pink-800">Upcoming Appointments</h2>
        <Card>
          <CardContent className="p-0">
            <div className="divide-y divide-pink-100">
              {appointments.map((appointment) => {
                const doctor = doctors.find((d) => d.id === appointment.doctorId)
                return (
                  <div key={appointment.id} className="flex items-center justify-between p-4">
                    <div>
                      <h3 className="font-medium text-pink-800">{appointment.type}</h3>
                      <p className="text-sm text-pink-600">{doctor?.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-pink-800">{format(new Date(appointment.date), "MMM d, h:mm a")}</p>
                      <p className="text-sm text-pink-600">{appointment.location}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
          <CardFooter className="bg-pink-50 px-4 py-3">
            <Button
              variant="outline"
              className="w-full border-pink-300 text-pink-700 hover:bg-pink-100"
              onClick={() => setShowAppointmentForm(true)}
            >
              Schedule New Appointment
            </Button>
          </CardFooter>
        </Card>
      </div>

      <AppointmentForm open={showAppointmentForm} onOpenChange={setShowAppointmentForm} />
    </div>
  )
}

