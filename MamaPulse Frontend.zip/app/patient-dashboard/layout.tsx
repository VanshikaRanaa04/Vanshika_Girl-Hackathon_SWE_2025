import type React from "react"
import Link from "next/link"
import { User, Bell, Settings, LogOut, Baby, Heart, Egg } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PatientDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen flex-col bg-pink-50">
      <header className="border-b border-pink-200 bg-white px-4 py-3 shadow-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <Link href="/patient-dashboard">
            <h1 className="text-xl font-bold text-pink-700">MamaPulse</h1>
          </Link>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-pink-700 hover:bg-pink-100 hover:text-pink-800">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-pink-700 hover:bg-pink-100 hover:text-pink-800">
              <Settings className="h-5 w-5" />
            </Button>
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-pink-700 hover:bg-pink-100 hover:text-pink-800">
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
            <Button
              variant="outline"
              className="ml-2 gap-2 border-pink-200 text-pink-700 hover:bg-pink-100 hover:text-pink-800"
            >
              <User className="h-4 w-4" />
              <span>Gauri</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto w-full max-w-7xl px-4 py-6">
        <Tabs defaultValue="preconception" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-pink-100">
            <TabsTrigger
              value="preconception"
              className="flex items-center gap-2 data-[state=active]:bg-pink-600 data-[state=active]:text-white"
              asChild
            >
              <Link href="/patient-dashboard/preconception">
                <Egg className="h-4 w-4" />
                <span className="hidden sm:inline">Preconception Planning</span>
                <span className="sm:hidden">Preconception</span>
              </Link>
            </TabsTrigger>
            <TabsTrigger
              value="pregnancy"
              className="flex items-center gap-2 data-[state=active]:bg-pink-600 data-[state=active]:text-white"
              asChild
            >
              <Link href="/patient-dashboard/pregnancy">
                <Heart className="h-4 w-4" />
                <span className="hidden sm:inline">Pregnancy & Maternal Care</span>
                <span className="sm:hidden">Pregnancy</span>
              </Link>
            </TabsTrigger>
            <TabsTrigger
              value="postpartum"
              className="flex items-center gap-2 data-[state=active]:bg-pink-600 data-[state=active]:text-white"
              asChild
            >
              <Link href="/patient-dashboard/postpartum">
                <Baby className="h-4 w-4" />
                <span className="hidden sm:inline">Postpartum & Childcare</span>
                <span className="sm:hidden">Postpartum</span>
              </Link>
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <main className="mt-6">{children}</main>
      </div>
    </div>
  )
}

