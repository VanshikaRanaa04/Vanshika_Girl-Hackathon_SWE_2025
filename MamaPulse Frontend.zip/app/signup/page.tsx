"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { User, Stethoscope, ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"

export default function SignupPage() {
  const router = useRouter()
  const [role, setRole] = useState<string>("patient")

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, you would handle registration here
    if (role === "patient") {
      router.push("/patient-dashboard")
    } else {
      router.push("/doctor-dashboard")
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-pink-50">
      <div className="flex flex-1 items-center justify-center px-4 py-12">
        <div className="w-full max-w-md space-y-6">
          <div className="space-y-2 text-center">
            <Link href="/" className="inline-flex items-center text-pink-700 hover:text-pink-800">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Link>
            <h1 className="text-3xl font-bold text-pink-800">Create an Account</h1>
            <p className="text-pink-600">Sign up to get started with MaternalCare</p>
          </div>

          <Tabs defaultValue={role} onValueChange={setRole} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-pink-100">
              <TabsTrigger value="patient" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
                <User className="mr-2 h-4 w-4" />
                Patient
              </TabsTrigger>
              <TabsTrigger value="doctor" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
                <Stethoscope className="mr-2 h-4 w-4" />
                Doctor
              </TabsTrigger>
            </TabsList>

            <TabsContent value="patient" className="mt-6">
              <form onSubmit={handleSignup} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="patient-first-name">First Name</Label>
                    <Input id="patient-first-name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="patient-last-name">Last Name</Label>
                    <Input id="patient-last-name" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="patient-email">Email</Label>
                  <Input id="patient-email" type="email" placeholder="patient@example.com" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="patient-password">Password</Label>
                  <Input id="patient-password" type="password" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="patient-confirm-password">Confirm Password</Label>
                  <Input id="patient-confirm-password" type="password" required />
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="patient-terms" required />
                  <Label htmlFor="patient-terms" className="text-sm">
                    I agree to the{" "}
                    <Link href="/terms" className="text-pink-700 hover:text-pink-800">
                      Terms of Service
                    </Link>{" "}
                    and{" "}
                    <Link href="/privacy" className="text-pink-700 hover:text-pink-800">
                      Privacy Policy
                    </Link>
                  </Label>
                </div>
                <Button type="submit" className="w-full bg-pink-600 hover:bg-pink-700">
                  Create Patient Account
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="doctor" className="mt-6">
              <form onSubmit={handleSignup} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="doctor-first-name">First Name</Label>
                    <Input id="doctor-first-name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="doctor-last-name">Last Name</Label>
                    <Input id="doctor-last-name" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="doctor-email">Email</Label>
                  <Input id="doctor-email" type="email" placeholder="doctor@example.com" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="doctor-specialty">Specialty</Label>
                  <Input id="doctor-specialty" placeholder="e.g., Gynecology, Obstetrics" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="doctor-license">License Number</Label>
                  <Input id="doctor-license" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="doctor-password">Password</Label>
                  <Input id="doctor-password" type="password" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="doctor-confirm-password">Confirm Password</Label>
                  <Input id="doctor-confirm-password" type="password" required />
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="doctor-terms" required />
                  <Label htmlFor="doctor-terms" className="text-sm">
                    I agree to the{" "}
                    <Link href="/terms" className="text-pink-700 hover:text-pink-800">
                      Terms of Service
                    </Link>{" "}
                    and{" "}
                    <Link href="/privacy" className="text-pink-700 hover:text-pink-800">
                      Privacy Policy
                    </Link>
                  </Label>
                </div>
                <Button type="submit" className="w-full bg-pink-600 hover:bg-pink-700">
                  Create Doctor Account
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          <div className="text-center text-sm">
            Already have an account?{" "}
            <Link href="/login" className="font-medium text-pink-700 hover:text-pink-800">
              Sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

