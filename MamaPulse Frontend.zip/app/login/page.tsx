"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { User, Stethoscope, ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [role, setRole] = useState<string>("patient")

  useEffect(() => {
    const roleParam = searchParams.get("role")
    if (roleParam && (roleParam === "patient" || roleParam === "doctor")) {
      setRole(roleParam)
    }
  }, [searchParams])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, you would handle authentication here
    if (role === "patient") {
      router.push("/patient-dashboard")
    } else {
      router.push("/doctor-dashboard")
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-pink-50">
      <div className="flex flex-1 items-center justify-center px-4 py-12">
        <div className="w-full max-w-md space-y-6">
          <div className="space-y-2 text-center">
            <Link href="/" className="inline-flex items-center text-pink-700 hover:text-pink-800">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Link>
            <h1 className="text-3xl font-bold text-pink-800">Welcome Back</h1>
            <p className="text-pink-600">Sign in to your account to continue</p>
          </div>

          <Tabs defaultValue={role} onValueChange={setRole} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-pink-100">
              <TabsTrigger value="patient" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
                <User className="mr-2 h-4 w-4" />
                Patient
              </TabsTrigger>
              <TabsTrigger value="doctor" className="data-[state=active]:bg-pink-600 data-[state=active]:text-white">
                <Stethoscope className="mr-2 h-4 w-4" />
                Doctor
              </TabsTrigger>
            </TabsList>

            <TabsContent value="patient" className="mt-6">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="patient-email">Email</Label>
                  <Input id="patient-email" type="email" placeholder="patient@example.com" required />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="patient-password">Password</Label>
                    <Link href="/forgot-password" className="text-xs text-pink-700 hover:text-pink-800">
                      Forgot password?
                    </Link>
                  </div>
                  <Input id="patient-password" type="password" required />
                </div>
                <Button type="submit" className="w-full bg-pink-600 hover:bg-pink-700">
                  Sign In as Patient
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="doctor" className="mt-6">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="doctor-email">Email</Label>
                  <Input id="doctor-email" type="email" placeholder="doctor@example.com" required />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="doctor-password">Password</Label>
                    <Link href="/forgot-password" className="text-xs text-pink-700 hover:text-pink-800">
                      Forgot password?
                    </Link>
                  </div>
                  <Input id="doctor-password" type="password" required />
                </div>
                <Button type="submit" className="w-full bg-pink-600 hover:bg-pink-700">
                  Sign In as Doctor
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          <div className="text-center text-sm">
            Don&apos;t have an account?{" "}
            <Link href="/signup" className="font-medium text-pink-700 hover:text-pink-800">
              Sign up
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

